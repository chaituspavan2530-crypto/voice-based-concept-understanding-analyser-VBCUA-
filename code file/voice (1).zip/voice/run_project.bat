@echo off
title VibeVoice Launcher
echo ==========================================================
echo               VibeVoice Launcher ^& Checker
echo ==========================================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in your system PATH.
    echo Please download and install Python from: https://www.python.org/
    echo or install it via the Microsoft Store.
    echo.
    pause
    exit /b
)

:: Display detected python version
echo [INFO] Detected Python environment:
python --version
echo.

:: Check libraries in the current Python environment
echo [INFO] Checking required libraries (Flask, Flask-CORS, SpeechRecognition)...
python -c "import flask, flask_cors, speech_recognition" >nul 2>&1

if %errorlevel% neq 0 (
    echo [WARN] Missing required Python libraries.
    echo [INFO] Installing dependencies using 'python -m pip install'...
    echo.
    
    python -m pip install -r requirements.txt
    
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Installation failed. Please check your internet connection.
        echo.
        pause
        exit /b
    )
    echo.
    echo [SUCCESS] All libraries installed successfully.
    echo.
) else (
    echo [SUCCESS] All required libraries are already installed!
    echo.
)

echo ==========================================================
echo Starting VibeVoice backend server...
echo Access the application in your browser at: http://127.0.0.1:5000/
echo.
echo Press CTRL+C in this command window to stop the server.
echo ==========================================================
echo.

python app.py

:: In case the script crashes or stops, keep window open to see output
echo.
echo Server has stopped.
pause
