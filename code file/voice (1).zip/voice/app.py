import os
import time
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, abort
from flask_cors import CORS
import speech_recognition as sr

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)  # Enable Cross-Origin Resource Sharing for all routes

# Define directories
TRANSCRIPTIONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'transcriptions')
TEMP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp')

# Ensure directories exist
os.makedirs(TRANSCRIPTIONS_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

@app.route('/')
def index():
    """Serve the main frontend application."""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/transcribe', methods=['POST'])
def transcribe_audio():
    """Receive WAV audio file, transcribe it, and save the result as a .txt file."""
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided in request.'}), 400
    
    audio_file = request.files['audio']
    if audio_file.filename == '':
        return jsonify({'error': 'Empty filename.'}), 400

    # Save to a temporary file
    temp_filename = f"temp_{int(time.time() * 1000)}.wav"
    temp_path = os.path.join(TEMP_DIR, temp_filename)
    audio_file.save(temp_path)

    recognizer = sr.Recognizer()
    
    try:
        # Load the audio file into speech recognition
        with sr.AudioFile(temp_path) as source:
            # Adjust for ambient noise (brief calibration)
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio_data = recognizer.record(source)
        
        # Perform speech-to-text using Google Speech Recognition
        # It's free, requires no API key, and works out of the box
        text = recognizer.recognize_google(audio_data)
        
        # Clean text
        text = text.strip()
        
        if not text:
            raise sr.UnknownValueError("Transcription yielded empty text.")

        # Generate local Notepad .txt file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        txt_filename = f"transcription_{timestamp}.txt"
        txt_path = os.path.join(TRANSCRIPTIONS_DIR, txt_filename)
        
        # Save transcription to file
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(text)

        return jsonify({
            'success': True,
            'text': text,
            'filename': txt_filename,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

    except sr.UnknownValueError:
        return jsonify({
            'success': False,
            'error': 'Speech could not be understood. Please try speaking more clearly or check the audio quality.'
        }), 422
    except sr.RequestError as e:
        return jsonify({
            'success': False,
            'error': f'Speech recognition service request failed: {str(e)}. Please check your network connection.'
        }), 503
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'An unexpected error occurred during audio processing: {str(e)}'
        }), 500
    finally:
        # Clean up temporary WAV file
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception as e:
                print(f"Error removing temporary file {temp_path}: {e}")

@app.route('/api/transcriptions', methods=['GET'])
def list_transcriptions():
    """List all saved .txt transcriptions with metadata."""
    try:
        files = []
        for filename in os.listdir(TRANSCRIPTIONS_DIR):
            if filename.endswith('.txt'):
                filepath = os.path.join(TRANSCRIPTIONS_DIR, filename)
                stat = os.stat(filepath)
                
                # Try reading a snippet of the file
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        snippet = f.read(120)
                        if len(snippet) >= 120:
                            snippet += '...'
                except Exception:
                    snippet = 'Unable to read content.'
                
                # Format time
                created_time = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                
                files.append({
                    'filename': filename,
                    'size': stat.st_size,
                    'created_at': created_time,
                    'snippet': snippet,
                    'timestamp_raw': stat.st_mtime
                })
        
        # Sort by creation time descending (newest first)
        files.sort(key=lambda x: x['timestamp_raw'], reverse=True)
        return jsonify({'success': True, 'transcriptions': files})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/transcriptions/download/<filename>', methods=['GET'])
def download_transcription(filename):
    """Download a specific .txt file."""
    # Prevent directory traversal attacks
    if '/' in filename or '\\' in filename or filename == '..' or not filename.endswith('.txt'):
        abort(400, "Invalid filename")
    
    file_path = os.path.join(TRANSCRIPTIONS_DIR, filename)
    if not os.path.exists(file_path):
        abort(404, "File not found")
        
    return send_from_directory(TRANSCRIPTIONS_DIR, filename, as_attachment=True)

@app.route('/api/transcriptions/delete/<filename>', methods=['DELETE'])
def delete_transcription(filename):
    """Delete a transcription text file."""
    if '/' in filename or '\\' in filename or filename == '..' or not filename.endswith('.txt'):
        abort(400, "Invalid filename")
        
    file_path = os.path.join(TRANSCRIPTIONS_DIR, filename)
    if not os.path.exists(file_path):
        abort(404, "File not found")
        
    try:
        os.remove(file_path)
        return jsonify({'success': True, 'message': f'File {filename} deleted successfully.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    print("Starting Flask Voice Recorder & Transcriber Server...")
    print(f"Transcriptions directory: {TRANSCRIPTIONS_DIR}")
    app.run(host='127.0.0.1', port=5000, debug=True)
