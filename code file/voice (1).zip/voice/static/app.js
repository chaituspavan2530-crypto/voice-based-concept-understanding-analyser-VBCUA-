// Toast Notification System
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'info';
    if (type === 'success') icon = 'check-circle-2';
    if (type === 'error') icon = 'alert-triangle';
    
    toast.innerHTML = `
        <i data-lucide="${icon}"></i>
        <span>${message}</span>
        <button class="toast-close">&times;</button>
    `;
    
    container.appendChild(toast);
    lucide.createIcons(); // render icon
    
    // Close on click
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.style.animation = 'toastIn 0.2s reverse forwards';
        setTimeout(() => toast.remove(), 200);
    });
    
    // Auto remove
    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.animation = 'toastIn 0.2s reverse forwards';
            setTimeout(() => toast.remove(), 200);
        }
    }, 4000);
}

// Global Variables
let audioContext = null;
let mediaStream = null;
let scriptProcessor = null;
let analyser = null;
let sourceNode = null;
let recordingBuffer = [];
let recordingLength = 0;
let isRecording = false;
let startTime = 0;
let timerInterval = null;
let animationFrameId = null;

// DOM Elements
const recordBtn = document.getElementById('recordBtn');
const recordIcon = document.getElementById('recordIcon');
const recorderStatus = document.getElementById('recorderStatus');
const recordingTimer = document.getElementById('recordingTimer');
const waveformCanvas = document.getElementById('waveformCanvas');
const canvasCtx = waveformCanvas.getContext('2d');

const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileInfo = document.getElementById('fileInfo');
const fileNameSpan = document.getElementById('fileName');
const fileSizeSpan = document.getElementById('fileSize');
const clearFileBtn = document.getElementById('clearFileBtn');
const processUploadBtn = document.getElementById('processUploadBtn');

const globalStatusPanel = document.getElementById('globalStatusPanel');
const statusMessage = document.getElementById('statusMessage');
const progressBar = document.getElementById('progressBar');
const statusPercentage = document.getElementById('statusPercentage');

const resultSection = document.getElementById('resultSection');
const resultTextarea = document.getElementById('resultTextarea');
const copyTextBtn = document.getElementById('copyTextBtn');
const downloadTxtBtn = document.getElementById('downloadTxtBtn');
const creationNotice = document.getElementById('creationNotice');
const savedFilenameSpan = document.getElementById('savedFilename');

const historyList = document.getElementById('historyList');

// Selected audio file state
let selectedFile = null;
let currentTranscribedText = '';
let currentFilename = '';

// Initialize Lucide Icons
lucide.createIcons();

// Load history on startup
loadHistory();

/* --- History List Functions --- */
async function loadHistory() {
    try {
        const response = await fetch('/api/transcriptions');
        const data = await response.json();
        
        if (data.success) {
            renderHistory(data.transcriptions);
        } else {
            historyList.innerHTML = `<div class="empty-history">Failed to load history: ${data.error}</div>`;
        }
    } catch (error) {
        console.error('Error fetching history:', error);
        historyList.innerHTML = `<div class="empty-history">Error connecting to server.</div>`;
    }
}

function renderHistory(items) {
    if (!items || items.length === 0) {
        historyList.innerHTML = `
            <div class="empty-history">
                <i data-lucide="inbox" style="width: 32px; height: 32px;"></i>
                <p>No transcriptions yet</p>
            </div>
        `;
        lucide.createIcons();
        return;
    }
    
    historyList.innerHTML = '';
    items.forEach(item => {
        const div = document.createElement('div');
        div.className = `history-item ${item.filename === currentFilename ? 'active' : ''}`;
        div.dataset.filename = item.filename;
        
        // Human readable file size
        const kb = (item.size / 1024).toFixed(1);
        
        div.innerHTML = `
            <div class="history-item-header">
                <span class="history-name" title="${item.filename}">${item.filename}</span>
                <div class="history-actions">
                    <button class="hist-btn download-hist-btn" title="Download text file">
                        <i data-lucide="download" style="width: 13px; height: 13px;"></i>
                    </button>
                    <button class="hist-btn delete-btn" title="Delete record">
                        <i data-lucide="trash-2" style="width: 13px; height: 13px;"></i>
                    </button>
                </div>
            </div>
            <p class="history-snippet">${item.snippet || '(empty transcription)'}</p>
            <div class="history-meta">
                <span>${item.created_at}</span>
                <span>${kb} KB</span>
            </div>
        `;
        
        // Item click to view
        div.addEventListener('click', (e) => {
            // If clicking action buttons, don't trigger item selection
            if (e.target.closest('.hist-btn')) return;
            selectHistoryItem(item);
        });
        
        // Download action
        div.querySelector('.download-hist-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            window.open(`/api/transcriptions/download/${item.filename}`);
        });
        
        // Delete action
        div.querySelector('.delete-btn').addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm(`Are you sure you want to delete ${item.filename}?`)) {
                try {
                    const res = await fetch(`/api/transcriptions/delete/${item.filename}`, { method: 'DELETE' });
                    const resData = await res.json();
                    if (resData.success) {
                        showToast('File deleted successfully.', 'success');
                        loadHistory();
                        if (currentFilename === item.filename) {
                            resultSection.classList.add('hidden');
                            currentFilename = '';
                        }
                    } else {
                        showToast(`Failed to delete: ${resData.error}`, 'error');
                    }
                } catch (err) {
                    showToast('Error deleting file.', 'error');
                }
            }
        });
        
        historyList.appendChild(div);
    });
    
    lucide.createIcons();
}

async function selectHistoryItem(item) {
    // Highlight item
    document.querySelectorAll('.history-item').forEach(el => el.classList.remove('active'));
    const clickedItem = document.querySelector(`.history-item[data-filename="${item.filename}"]`);
    if (clickedItem) clickedItem.classList.add('active');
    
    // Load full content
    try {
        const response = await fetch(`/api/transcriptions/download/${item.filename}`);
        if (response.ok) {
            const text = await response.text();
            showResult(text, item.filename);
        } else {
            showToast('Could not load transcription content.', 'error');
        }
    } catch (error) {
        showToast('Error loading transcription content.', 'error');
    }
}


/* --- Audio Encoding Utilities (WAV Encoder) --- */
function writeString(view, offset, string) {
    for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}

// Encodes Float32Array PCM samples to 16-bit PCM WAV Blob
function encodeWAV(samples, sampleRate) {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);
    
    /* RIFF identifier */
    writeString(view, 0, 'RIFF');
    /* file length */
    view.setUint32(4, 36 + samples.length * 2, true);
    /* RIFF type */
    writeString(view, 8, 'WAVE');
    /* format chunk identifier */
    writeString(view, 12, 'fmt ');
    /* format chunk length */
    view.setUint32(16, 16, true);
    /* sample format (raw PCM) */
    view.setUint16(20, 1, true);
    /* channel count (mono) */
    view.setUint16(22, 1, true);
    /* sample rate */
    view.setUint32(24, sampleRate, true);
    /* byte rate (sample rate * block align) */
    view.setUint32(28, sampleRate * 2, true);
    /* block align (channel count * bytes per sample) */
    view.setUint16(32, 2, true);
    /* bits per sample */
    view.setUint16(34, 16, true);
    /* data chunk identifier */
    writeString(view, 36, 'data');
    /* data chunk length */
    view.setUint32(40, samples.length * 2, true);
    
    // Write PCM audio samples
    let index = 44;
    for (let i = 0; i < samples.length; i++) {
        // Clamp sample values
        let s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(index, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        index += 2;
    }
    
    return new Blob([view], { type: 'audio/wav' });
}


/* --- Voice Recorder Controller --- */

// Render idle waveform on canvas
function drawIdleWaveform() {
    canvasCtx.clearRect(0, 0, waveformCanvas.width, waveformCanvas.height);
    canvasCtx.strokeStyle = 'rgba(139, 92, 246, 0.2)';
    canvasCtx.lineWidth = 2;
    canvasCtx.beginPath();
    canvasCtx.moveTo(0, waveformCanvas.height / 2);
    canvasCtx.lineTo(waveformCanvas.width, waveformCanvas.height / 2);
    canvasCtx.stroke();
}
drawIdleWaveform();

function startTimer() {
    startTime = Date.now();
    timerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime) / 1000);
        const minutes = String(Math.floor(elapsed / 60)).padStart(2, '0');
        const seconds = String(elapsed % 60).padStart(2, '0');
        recordingTimer.textContent = `${minutes}:${seconds}`;
    }, 1000);
}

function stopTimer() {
    clearInterval(timerInterval);
    recordingTimer.textContent = "00:00";
}

function updateVisualizer() {
    if (!isRecording) return;
    
    animationFrameId = requestAnimationFrame(updateVisualizer);
    
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyser.getByteTimeDomainData(dataArray);
    
    canvasCtx.clearRect(0, 0, waveformCanvas.width, waveformCanvas.height);
    canvasCtx.lineWidth = 2;
    
    // Gradient wave style
    const gradient = canvasCtx.createLinearGradient(0, 0, waveformCanvas.width, 0);
    gradient.addColorStop(0, '#8b5cf6');
    gradient.addColorStop(1, '#3b82f6');
    canvasCtx.strokeStyle = gradient;
    
    canvasCtx.beginPath();
    
    const sliceWidth = waveformCanvas.width / bufferLength;
    let x = 0;
    
    for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * waveformCanvas.height) / 2;
        
        if (i === 0) {
            canvasCtx.moveTo(x, y);
        } else {
            canvasCtx.lineTo(x, y);
        }
        
        x += sliceWidth;
    }
    
    canvasCtx.lineTo(waveformCanvas.width, waveformCanvas.height / 2);
    canvasCtx.stroke();
}

async function startRecording() {
    recordingBuffer = [];
    recordingLength = 0;
    
    try {
        // Request Microphone Access
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // Initialize Web Audio API
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        
        sourceNode = audioContext.createMediaStreamSource(mediaStream);
        
        // Set up recording processor node (2048 buffer size, 1 input, 1 output)
        scriptProcessor = audioContext.createScriptProcessor(2048, 1, 1);
        scriptProcessor.onaudioprocess = (e) => {
            const inputBuffer = e.inputBuffer.getChannelData(0);
            recordingBuffer.push(new Float32Array(inputBuffer));
            recordingLength += inputBuffer.length;
        };
        
        // Link nodes
        sourceNode.connect(analyser);
        sourceNode.connect(scriptProcessor);
        scriptProcessor.connect(audioContext.destination);
        
        // State updates
        isRecording = true;
        recordBtn.classList.add('recording');
        recordIcon.setAttribute('data-lucide', 'square');
        lucide.createIcons();
        recorderStatus.textContent = "Recording... Click to stop";
        showToast("Recording started", "success");
        
        startTimer();
        updateVisualizer();
        
    } catch (err) {
        console.error('Error starting recording:', err);
        showToast("Microphone access denied or error starting recording.", "error");
        isRecording = false;
        recordBtn.classList.remove('recording');
        recordStatusNormal();
    }
}

function recordStatusNormal() {
    recordIcon.setAttribute('data-lucide', 'mic');
    lucide.createIcons();
    recorderStatus.textContent = "Click to start recording";
}

async function stopRecording() {
    if (!isRecording) return;
    
    // Stop recording state
    isRecording = false;
    stopTimer();
    cancelAnimationFrame(animationFrameId);
    
    recordBtn.classList.remove('recording');
    recordStatusNormal();
    
    // Clean up streams & nodes
    scriptProcessor.disconnect();
    sourceNode.disconnect();
    mediaStream.getTracks().forEach(track => track.stop());
    
    if (audioContext.state !== 'closed') {
        await audioContext.close();
    }
    
    drawIdleWaveform();
    showToast("Recording finished. Transcribing...", "info");
    
    // Flatten audio chunks
    const samples = new Float32Array(recordingLength);
    let offset = 0;
    for (let i = 0; i < recordingBuffer.length; i++) {
        samples.set(recordingBuffer[i], offset);
        offset += recordingBuffer[i].length;
    }
    
    // Encode to standard WAV
    const wavBlob = encodeWAV(samples, audioContext.sampleRate);
    
    // Send to backend
    uploadWavFile(wavBlob);
}

// Toggle recording state
recordBtn.addEventListener('click', () => {
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
});


/* --- File Upload Controller --- */

// Handle files dragging
['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.add('dragging');
    }, false);
});

['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragging');
    }, false);
});

dropZone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length > 0) {
        handleSelectedFile(files[0]);
    }
});

dropZone.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', (e) => {
    if (fileInput.files.length > 0) {
        handleSelectedFile(fileInput.files[0]);
    }
});

function handleSelectedFile(file) {
    if (!file.type.startsWith('audio/')) {
        showToast('Please select a valid audio file.', 'error');
        return;
    }
    
    selectedFile = file;
    
    // UI details
    fileNameSpan.textContent = file.name;
    const mb = (file.size / (1024 * 1024)).toFixed(2);
    fileSizeSpan.textContent = `${mb} MB`;
    
    // Show info, hide upload prompt
    dropZone.querySelector('.upload-content').classList.add('hidden');
    fileInfo.classList.remove('hidden');
    
    // Enable button
    processUploadBtn.removeAttribute('disabled');
}

clearFileBtn.addEventListener('click', (e) => {
    e.stopPropagation(); // stop click opening file browser
    clearSelectedFile();
});

function clearSelectedFile() {
    selectedFile = null;
    fileInput.value = '';
    
    // Toggle UI back
    fileInfo.classList.add('hidden');
    dropZone.querySelector('.upload-content').classList.remove('hidden');
    processUploadBtn.setAttribute('disabled', 'true');
}


/* --- Decode and Transcribe Actions --- */

processUploadBtn.addEventListener('click', async () => {
    if (!selectedFile) return;
    
    showToast('Decoding and uploading audio...', 'info');
    showProgress(true, 'Reading and decoding audio file...');
    
    try {
        // Read file to ArrayBuffer
        updateProgress(15, 'Reading file...');
        const arrayBuffer = await selectedFile.arrayBuffer();
        
        // Decode audio data using browser native decoder
        updateProgress(40, 'Decoding audio format...');
        const tempContext = new (window.AudioContext || window.webkitAudioContext)();
        const decodedBuffer = await tempContext.decodeAudioData(arrayBuffer);
        
        // Extract mono channel data
        updateProgress(75, 'Extracting channel data...');
        const samples = decodedBuffer.getChannelData(0);
        const sampleRate = decodedBuffer.sampleRate;
        
        // Encode to WAV PCM
        updateProgress(90, 'Encoding to WAV...');
        const wavBlob = encodeWAV(samples, sampleRate);
        
        await tempContext.close();
        
        updateProgress(100, 'Sending to server...');
        setTimeout(() => {
            showProgress(true, 'Transcribing audio on server (Google Speech API)...');
            uploadWavFile(wavBlob);
        }, 300);
        
    } catch (error) {
        console.error('Decoding failed:', error);
        showProgress(false);
        showToast('Browser failed to decode this audio file. Please try another file.', 'error');
    }
});

// Upload Wav to backend api
async function uploadWavFile(wavBlob) {
    showProgress(true, 'Uploading & Transcribing...');
    
    const formData = new FormData();
    formData.append('audio', wavBlob, 'recording.wav');
    
    try {
        const response = await fetch('/api/transcribe', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        showProgress(false);
        
        if (data.success) {
            showToast('Audio transcribed successfully!', 'success');
            showResult(data.text, data.filename);
            loadHistory(); // reload history panel
            clearSelectedFile(); // clear uploaded slot
        } else {
            showToast(data.error || 'Speech recognition failed.', 'error');
        }
    } catch (error) {
        console.error('API Error:', error);
        showProgress(false);
        showToast('Connection to transcription server failed.', 'error');
    }
}


/* --- Result Panel Actions --- */

function showResult(text, filename) {
    currentTranscribedText = text;
    currentFilename = filename;
    
    resultTextarea.value = text;
    savedFilenameSpan.textContent = filename;
    
    resultSection.classList.remove('hidden');
    
    // Scroll result into view smoothly
    resultSection.scrollIntoView({ behavior: 'smooth' });
}

copyTextBtn.addEventListener('click', () => {
    if (!currentTranscribedText) return;
    
    navigator.clipboard.writeText(currentTranscribedText)
        .then(() => {
            showToast('Text copied to clipboard!', 'success');
            copyTextBtn.innerHTML = `<i data-lucide="check"></i> Copied`;
            lucide.createIcons();
            
            setTimeout(() => {
                copyTextBtn.innerHTML = `<i data-lucide="copy"></i> Copy`;
                lucide.createIcons();
            }, 2000);
        })
        .catch(err => {
            showToast('Failed to copy text.', 'error');
        });
});

downloadTxtBtn.addEventListener('click', () => {
    if (!currentFilename) return;
    // Download directly from server using backend routing
    window.open(`/api/transcriptions/download/${currentFilename}`);
});


/* --- UI Progress Panel Helpers --- */

function showProgress(visible, message = 'Processing...') {
    if (visible) {
        globalStatusPanel.classList.remove('hidden');
        statusMessage.textContent = message;
        progressBar.style.width = '20%';
        statusPercentage.textContent = 'Active';
    } else {
        globalStatusPanel.classList.add('hidden');
    }
}

function updateProgress(percent, message) {
    progressBar.style.width = `${percent}%`;
    statusPercentage.textContent = `${percent}%`;
    if (message) {
        statusMessage.textContent = message;
    }
}
